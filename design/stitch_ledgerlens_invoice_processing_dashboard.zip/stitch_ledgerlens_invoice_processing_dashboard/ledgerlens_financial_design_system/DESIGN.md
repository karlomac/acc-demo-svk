---
name: LedgerLens Financial Design System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434654'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#747686'
  outline-variant: '#c4c5d7'
  surface-tint: '#2353d5'
  primary: '#003bb4'
  on-primary: '#ffffff'
  primary-container: '#2554d6'
  on-primary-container: '#d2d9ff'
  inverse-primary: '#b6c4ff'
  secondary: '#555f71'
  on-secondary: '#ffffff'
  secondary-container: '#d6e0f5'
  on-secondary-container: '#596375'
  tertiary: '#812c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#a83c00'
  on-tertiary-container: '#ffd0bf'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#001550'
  on-primary-fixed-variant: '#003ab1'
  secondary-fixed: '#d9e3f8'
  secondary-fixed-dim: '#bdc7db'
  on-secondary-fixed: '#121c2b'
  on-secondary-fixed-variant: '#3d4758'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb599'
  on-tertiary-fixed: '#370e00'
  on-tertiary-fixed-variant: '#7f2b00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  numeric-table:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style
The design system establishes an institutional, high-trust fintech aesthetic tailored for accounts payable automation and high-velocity invoice processing. Designed for finance controllers, AP clerks, and auditors, the interface conveys absolute precision, verifiable accuracy, and calm under operational scale.

Drawing from modern Corporate Minimalism, the system prioritizes high-density data parsing over decorative flair. Crisp, low-contrast structural dividers replace aggressive depth, giving precedence to numerical telemetry, verification flags, and audit trails. Visual rhythm relies on exact mathematical alignment, standardized semantic badge tiers, and unambiguous state feedback.

## Colors
The palette balances an authoritative primary cobalt with clinical neutral backdrops to maintain compliance with strict contrast requirements (WCAG 2.1 AAA on core copy).

- **Canvas Background (`#FAFBFC`)**: A cool, low-fatigue slate wash engineered for extended daily ledger review.
- **Surface / Cards (`#FFFFFF`)**: Pure white containers with crisp definition against the canvas.
- **Primary Brand (`#2554D6`)**: Signals key actions, selected states, and navigational anchors. Complemented by `#1B43B3` (active/hover) and `#EFF4FF` (subtle active fills).
- **Text & Hierarchy**: Primary headings and values command attention in dark slate (`#0F172A`), while supporting labels and secondary metadata render in balanced gray (`#5B6577`).
- **Semantic Status Tiers**:
  - *Needs Review / Pending*: `#1D4ED8` text on `#E7EEFF` fill with `#C7D9FE` hairline border.
  - *Flagged / Disputed / Error*: `#B91C1C` text on `#FDECEC` fill with `#F87171` hairline border.
  - *Approved / Matched / Cleared*: `#15803D` text on `#E8F6EC` fill with `#86EFAC` hairline border.
  - *Skipped / Archived / Neutral*: `#475569` text on `#F1F5F9` fill with `#CBD5E1` hairline border.
- **Borders & Dividers (`#E3E6EB`)**: A muted 1px rule applied across tables, panels, and input boundaries to isolate dense data clusters without visual clutter.

## Typography
Typographic discipline is anchored by Inter across all touchpoints. Visual stability is non-negotiable for enterprise financial tools:

- **Tabular Figures**: Every currency, ledger quantity, percentage, and date string enforces OpenType tabular numerals (`tnum`, `cv05`) to prevent vertical jitter across rows and columns.
- **Vertical Rhythm**: Tight line heights minimize dead space in dense data grids and inspector panels while preserving legibility.
- **Hierarchy Distinction**: Hierarchy is expressed primarily through font weight (600/700 vs 400) and optical color contrast (`#0F172A` vs `#5B6577`) rather than aggressive scaling of font size.

## Layout & Spacing
The layout model deploys a fluid 12-column grid constrained to a maximum content width of 1600px, flanked by fixed navigation and contextual side inspectors.

- **Desktop (>=1280px)**: 12 columns, 24px (`gutter-lg`) gutters, 24px (`margin`) margins. Accommodates two-up split views: an optical character recognition (OCR) preview canvas alongside an editable data inspector.
- **Tablet (768px - 1279px)**: 8 columns, 16px (`gutter`) gutters, 20px margins. Side sheets transition to modal overlays or stacked panes.
- **Mobile (<768px)**: 4 columns, 16px gutters, 16px (`margin-mobile`) margins. Tables collapse to expandable record cards.
- **Component Density**: Spacing within interactive controls follows an 8pt base grid with a 4pt sub-grid for internal padding (`space-xs`, `space-sm`) to support dense data auditing.

## Elevation & Depth
The system utilizes tonal boundary layering and subtle micro-shadows rather than dramatic multi-layered drop shadows. This maintains a clean, professional, and tactile surface model.

- **Level 0 (Base Canvas)**: Flat `#FAFBFC`, unbordered.
- **Level 1 (Cards, Tables, Panels)**: `#FFFFFF` surface bounded by a continuous 1px solid `#E3E6EB` border, reinforced by a micro-ambient shadow: `0 1px 2px 0 rgba(15, 23, 42, 0.05)`.
- **Level 2 (Hover States, Sticky Column Headers, Filter Bars)**: `#FFFFFF` surface with `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Reviewer Action Banners, Modals, Slide-Over Inspectors)**: Suspended elevated surfaces with `0 10px 15px -3px rgba(15, 23, 42, 0.1), 0 4px 6px -4px rgba(15, 23, 42, 0.05)` and a reinforced 1px perimeter border.

## Shapes
Shapes maintain balanced enterprise contours. Base interactive elements (buttons, inputs, status tags) use `rounded` (0.5rem / 8px). 

Larger structural containers such as stat metric cards, file upload dropzones, and modal dialogs extend to `rounded-xl` (1.5rem / 24px) or `rounded-lg` (1rem / 16px) to frame multi-tiered financial telemetry. Inner nesting adheres strictly to concentric corner math ($R_{inner} = R_{outer} - padding$) to eliminate asymmetric corner gaps.

## Components

### Buttons
- **Primary**: Solid `#2554D6` fill, `#FFFFFF` text, `rounded` (8px), height 36px (compact) or 40px (default). On hover: `#1B43B3`. Focus: 2px ring offset with `#2554D6`.
- **Secondary / Outline**: `#FFFFFF` background, 1px solid `#E3E6EB`, `#0F172A` text. Hover: `#FAFBFC` fill with `#CBD5E1` border.
- **Destructive**: `#B91C1C` text, `#FDECEC` background, 1px solid `#F87171`. Hover: `#DC2626` text, `#FEE2E2` fill.

### Status Badge Chips
- Built with a 20px fixed height, 6px horizontal padding, and pill geometry.
- Font styling leverages `label-sm` (11px, weight 600, tabular).
- Applied strictly with corresponding semantic fills and 1px borders (e.g., Needs Review: `#E7EEFF` fill, `#C7D9FE` border, `#1D4ED8` text).

### High-Density Data Tables
- Row height: 44px standard, alternating or flat `#FFFFFF` with 1px `#E3E6EB` bottom divider.
- Headers: `#FAFBFC` background, 11px uppercase `label-sm` text in `#5B6577`, sorting indicators.
- Right-aligned tabular numeric formatting for monetary columns ($0.00).
- Row hover: `#F8FAFC` transition with an absolute 2px primary accent bar on the left edge.

### Stat Cards
- Container: `#FFFFFF` fill, 1px solid `#E3E6EB`, `rounded-lg`, 16px padding.
- Structure: Micro-label header (`#5B6577`), primary numeric metric (`display-lg`, `#0F172A`), bottom trend badge showing variance against prior periods.

### Drag-and-Drop Invoice Upload Zone
- Container: 2px dashed `#CBD5E1` border, `rounded-xl`, background `#FAFBFC`.
- Active drop state: `#EFF4FF` fill with 2px dashed `#2554D6`.
- Central action icon, drag instructions in `body-sm`, and secondary link button for manual local browsing.

### Expandable Metadata Inspector
- Sticky right-rail drawer, 380px fixed width, left border 1px solid `#E3E6EB`.
- Structured in accordion sections with tabular key-value pairs (GL Account, Tax ID, PO Match Status).

### Reviewer Action Banner
- Sticky bottom or top ledger banner for fast batch approvals.
- High-contrast surface (`#0F172A` text on pure white card, elevated Level 3) featuring shortcut triggers (`Approve [A]`, `Flag [F]`, `Skip [S]`).